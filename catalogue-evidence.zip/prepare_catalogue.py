from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request,urlopen
from collections import Counter
import json,re,csv,unicodedata,hashlib

folder=Path(__file__).parent/'catalogue'
meta=json.loads((folder/'source_request.json').read_text())
data=json.loads((folder/'source.json').read_bytes())
pages=[data]
for page in ():
    cache=folder/f'page_{page}.json'
    if not cache.exists():
        url=meta['url'].replace('page=1&','page='+str(page)+'&')
        with urlopen(Request(url,headers={'User-Agent':'JimohCataloguePortfolio/1.0 (https://abdulghaffurjimoh.github.io/)'}),timeout=55) as response: cache.write_bytes(response.read())
    pages.append(json.loads(cache.read_bytes()))
products=[p for page in pages for p in page['products']]
meta['sample']='First API search page (100 records), United Kingdom country tag, most recently modified first. A convenience sample, not a representative market sample.'
meta['returned_rows']=len(products)

def clean(value):
    return re.sub(r'\s+',' ',unicodedata.normalize('NFC',str(value or ''))).strip()
def barcode_valid(code):
    if not code.isdigit() or len(code) not in (8,12,13,14): return False
    digits=list(map(int,code)); total=sum(d*(3 if i%2==0 else 1) for i,d in enumerate(reversed(digits[:-1])))
    return (10-total%10)%10==digits[-1]
def quantity(value):
    # Only parse one explicit mass/volume amount. Multipacks and conflicting quantities require review.
    m=re.fullmatch(r'(\d+(?:[.,]\d+)?)\s*(kg|g|mg|l|ml|cl)',clean(value),re.I)
    if not m:return None,None,None
    amount=float(m[1].replace(',','.'));unit=m[2].lower()
    if amount<=0:return None,None,None
    base,normal={'kg':(amount*1000,'g'),'g':(amount,'g'),'mg':(amount/1000,'g'),'l':(amount*1000,'ml'),'cl':(amount*10,'ml'),'ml':(amount,'ml')}[unit]
    return round(base,6),normal,f'{amount:g} {unit if unit!="l" else "L"}'
counts=Counter(clean(p.get('code')) for p in products)
records=[];changes=[];issues=[]
for i,p in enumerate(products,1):
    code=clean(p.get('code'));name=clean(p.get('product_name'));brand=clean(p.get('brands'));qty=clean(p.get('quantity'));category=clean(p.get('categories'))
    amount,unit,label=quantity(qty)
    flags=[]
    if not name:flags.append(('Missing name','Confirm the product name against the packaging or supplier record.'))
    if not brand:flags.append(('Missing brand','Confirm the brand with the supplier; do not infer it from the name.'))
    if not qty:flags.append(('Missing pack size','Request the sellable pack size and unit.'))
    elif amount is None:flags.append(('Pack size needs review','Check the pack structure; a multipack or ambiguous quantity was not converted.'))
    if not category:flags.append(('Missing category','Assign the store category after confirming the product.'))
    if not barcode_valid(code):flags.append(('Barcode needs review','Check the original identifier; no digits were repaired or padded.'))
    if counts[code]>1:flags.append(('Repeated source code','Compare overlapping snapshot records before selecting one; no row was silently deleted.'))
    output={'source_row':i,'barcode':code,'product_name':name,'brand':brand,'pack_size':label or qty,'base_quantity':amount,'base_unit':unit or '', 'source_categories':category,'review_status':'Needs review' if flags else 'Passes selected checks','issue_count':len(flags),'issues':'; '.join(f[0] for f in flags),'next_action':' '.join(f[1] for f in flags) if flags else 'Confirm store-specific price, inventory, images and category mapping before any import.','source_url':'https://world.openfoodfacts.org/product/'+code}
    records.append(output)
    for field,target in [('product_name','product_name'),('brands','brand'),('quantity','pack_size'),('categories','source_categories')]:
        before=str(p.get(field,'') or '');after=str(output[target])
        if before!=after:changes.append({'source_row':i,'barcode':code,'field':field,'before':before,'after':after,'rule':'Explicit single-pack quantity formatting' if field=='quantity' and label else 'Unicode NFC and whitespace only'})
    for issue,action in flags:issues.append({'source_row':i,'barcode':code,'product_name':name,'issue':issue,'next_action':action,'source_url':output['source_url']})

def csvout(name,rows,fields=None):
    fields=fields or list(rows[0]);path=folder/name
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
csvout('catalogue-standardised.csv',records)
csvout('catalogue-review.csv',issues)
csvout('catalogue-changes.csv',changes, ['source_row','barcode','field','before','after','rule'])
csvout('catalogue-source.csv',[{'source_row':i,**{k:p.get(k,'') for k in ['code','product_name','product_name_en','brands','quantity','categories','lang']}} for i,p in enumerate(products,1)])
summary={'rows':len(records),'distinct_codes':len(counts),'passes':sum(r['review_status']=='Passes selected checks' for r in records),'review':sum(r['review_status']=='Needs review' for r in records),'issues':dict(Counter(x['issue'] for x in issues)),'changed_fields':len(changes),'changed_products':len(set(x['source_row'] for x in changes)),'parsed_quantity':sum(r['base_quantity'] is not None for r in records),'source_sha256':hashlib.sha256((folder/'source.json').read_bytes()).hexdigest()}
payload={'meta':meta,'summary':summary,'records':records,'changes':changes,'issues':issues,'source':products}
(folder/'analysis.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source_request.json').write_text(json.dumps(meta,indent=2))
print(json.dumps(summary,indent=2))
print('Change examples:',json.dumps(changes[:6],ensure_ascii=False))
print('Quantity examples:',json.dumps([r['pack_size'] for r in records if r['base_quantity'] is None][:10]))
