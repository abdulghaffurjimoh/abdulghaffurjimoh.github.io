# Product catalogue quality review

Public-data portfolio exercise by Abdul-Ghaffur Jimoh. Snapshot: 19 November 2026.

## Result
100 records, 100 unique codes. 52 require source verification. 48 pass the selected checks. 34 pack labels and one product-name spacing issue were standardised; 55 explicit single-pack quantities could be expressed in g or ml. Issue counts overlap.

## Source and selection
Open Food Facts, https://world.openfoodfacts.org/api/v2/search?countries_tags=en%3Aunited-kingdom&page_size=300&page=1&sort_by=last_modified_t&fields=code%2Cproduct_name%2Cproduct_name_en%2Cbrands%2Cquantity%2Ccategories%2Ccategories_tags%2Clang%2Clast_modified_t
The request asked for 300 records; the API returned its capped page of 100. This project uses exactly those 100 returned records. UK-tagged, most recently modified first. Convenience sample, not representative of all products. Source pages can change after the snapshot.
SHA-256 of the original source JSON: aeb0108fcc5be95b0c6ca0168472434ab0a50eb3e78c3c1f6b1c1a9e669a531d

## Files
catalogue/source.json is the original API response. source_request.json records the query and scope. catalogue-source.csv preserves selected source fields. catalogue-standardised.csv contains all rows, review flags and source URLs. catalogue-review.csv is one row per issue, so a product may appear more than once. catalogue-changes.csv contains original and revised field values.

## Rules
Normalise Unicode NFC and whitespace. Parse only one explicit positive mass or volume with g, kg, mg, ml, cl or L. Keep multipacks and ambiguous quantities unconverted. Convert supported single quantities to g or ml. Preserve blank fields and product codes, including leading zeros. Validate GTIN lengths 8, 12, 13 and 14 and their check digits; validity does not verify identity. Flag missing product name, brand, pack size, category, ambiguous pack sizes, invalid check digits or repeated codes. Do not infer prices, inventory, variants, translations or a store taxonomy.

## Reproduce the prepared CSVs
Python 3, standard library only. From the extracted package directory run: python prepare_catalogue.py
The script reads the preserved snapshot in catalogue/ and writes the analysis and CSVs back into that folder. It makes no API requests. The Excel review is a prepared snapshot; changing a source field in Excel does not rerun these rules. Follow-up status is editable and its summary uses formulas. In Excel, import CSV barcode columns as Text to preserve leading zeros. The review workbook already stores them as text.

## Use limits
This is not a store import file. Verify missing/ambiguous fields with the supplier, map categories and variants, add prices/inventory/images, and test an import. No live client work, savings or commercial outcomes are claimed.

## Licence and attribution
Contains information from Open Food Facts (https://world.openfoodfacts.org/), made available under the Open Database License (ODbL 1.0): https://opendatacommons.org/licenses/odbl/1-0/
Derived extracts in this package are offered under ODbL 1.0. Individual database contents are available under DbCL 1.0: https://opendatacommons.org/licenses/dbcl/1-0/
