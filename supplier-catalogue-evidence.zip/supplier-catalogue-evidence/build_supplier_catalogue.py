#!/usr/bin/env python3
"""
Build a synthetic supplier-catalogue case study for the portfolio.

The sample is generated, not client work. It is designed to demonstrate:
  * three supplier files in different shapes;
  * duplicate SKUs, inconsistent SKU/price formats, missing or broken images;
  * duplicate product titles, category mismatches, invalid barcodes, discontinued items;
  * a traceable cleaned catalogue and import-ready files for Shopify, BigCommerce
    and a generic platform.

Run from this directory:
    python build_supplier_catalogue.py

Outputs are written to raw/, clean/, import-ready/, docs/, site/ and the workbook
Supplier_Catalogue_Review.xlsx in this directory.
"""

from __future__ import annotations

import csv
import json
import random
import re
import shutil
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BASE = Path(__file__).resolve().parent
RAW = BASE / "raw"
CLEAN = BASE / "clean"
IMPORT = BASE / "import-ready"
DOCS = BASE / "docs"
SITE = BASE / "site"

for directory in (RAW, CLEAN, IMPORT, DOCS, SITE):
    directory.mkdir(parents=True, exist_ok=True)

SEED = 20261119
rng = random.Random(SEED)

CHERRY = "301828"
MULBERRY = "853D68"
MAUVE = "B7A3B0"
OAT = "FFF8EA"
MUTED = "695260"
PALE = "F0E5E5"
PALE_GREEN = "E7EFE9"

BRANDS = [
    ("Northshore Home", "NH"),
    ("Harbor & Oak", "HO"),
    ("Lumen Works", "LW"),
    ("Field Notes Kitchen", "FN"),
]

# A second brand line uses a distinct collection word so the 250 titles do not
# accidentally collide. The only intended duplicate-title groups are the six
# variant groups whose option is missing from the title.
BRAND_LINES = {
    "Northshore Home": "Coastal",
    "Harbor & Oak": "Heritage",
    "Lumen Works": "Studio",
    "Field Notes Kitchen": "Everyday",
}

CATEGORIES = [
    ("Kitchen", "KIT"),
    ("Bathroom", "BAT"),
    ("Lighting", "LIG"),
    ("Storage", "STO"),
    ("Textiles", "TEX"),
    ("Outdoor", "OUT"),
    ("Office", "OFF"),
    ("Decor", "DEC"),
]

CATEGORY_BY_CODE = {code: name for name, code in CATEGORIES}
CATEGORY_CODES = {name: code for name, code in CATEGORIES}

BASE_NAMES = {
    "Kitchen": [
        "Stoneware Mug", "Linen Tea Towel", "Bamboo Cutlery Set", "Oak Serving Board",
        "Glass Carafe", "Cotton Apron", "Enamel Storage Tin", "Wooden Spice Rack",
        "Ceramic Butter Dish", "Stainless Steel Bottle", "Marble Pestle and Mortar",
        "Beechwood Chopping Board", "Stoneware Dinner Plate", "Glass Storage Jar",
        "Cotton Oven Glove", "Copper Measuring Cups", "Ceramic Pie Dish",
        "Acacia Salad Bowl", "Linen Bread Bag", "Stainless Steel Colander",
    ],
    "Bathroom": [
        "Ceramic Soap Dish", "Cotton Hand Towel", "Bamboo Bath Tray", "Glass Apothecary Bottle",
        "Stoneware Toothbrush Holder", "Linen Wash Bag", "Brass Towel Hook",
        "Marble Soap Dispenser", "Cotton Bath Mat", "Teak Shower Stool",
        "Ceramic Cotton Jar", "Woven Laundry Basket", "Glass Vanity Tray", "Bamboo Mirror",
        "Stoneware Tumbler", "Linen Shower Curtain", "Brass Robe Hook",
        "Ceramic Soap Dispenser", "Cotton Face Cloth", "Teak Bath Board",
    ],
    "Lighting": [
        "Brass Table Lamp", "Ceramic Table Lamp", "Linen Lamp Shade", "Glass Pendant Light",
        "Rattan Ceiling Light", "Metal Wall Light", "Marble Table Lamp", "Cotton Floor Lamp",
        "Brass Picture Light", "Ceramic Wall Sconce", "Oak Floor Lamp", "Glass Table Lamp",
        "Linen Pendant Shade", "Rattan Table Lamp", "Metal Desk Lamp", "Stoneware Lamp Base",
        "Brass Ceiling Light", "Ceramic Pendant Light", "Cotton Table Lamp", "Oak Wall Light",
    ],
    "Storage": [
        "Woven Storage Basket", "Oak Shelf Box", "Metal Desk Tray", "Linen Storage Bag",
        "Rattan Magazine Rack", "Wooden Crate", "Ceramic Utensil Pot", "Glass Display Jar",
        "Cotton Rope Basket", "Bamboo Drawer Organiser", "Metal Storage Tin", "Oak Filing Box",
        "Woven Floor Basket", "Linen Wardrobe Organiser", "Rattan Shelf Basket",
        "Wooden Tool Caddy", "Ceramic Brush Pot", "Glass Storage Canister",
        "Cotton Hanging Basket", "Bamboo Shoe Rack",
    ],
    "Textiles": [
        "Linen Cushion Cover", "Cotton Table Runner", "Wool Throw", "Linen Bedspread",
        "Cotton Napkin Set", "Jute Floor Rug", "Wool Cushion Cover", "Linen Tea Towel Set",
        "Cotton Bath Towel", "Woven Table Mat", "Linen Pillowcase", "Cotton Quilt",
        "Wool Blanket", "Jute Door Mat", "Linen Curtain Panel", "Cotton Beach Towel",
        "Woven Floor Runner", "Linen Duvet Cover", "Cotton Hand Towel Set", "Wool Seat Pad",
    ],
    "Outdoor": [
        "Terracotta Plant Pot", "Ceramic Planter", "Metal Lantern", "Wooden Garden Tray",
        "Cotton Deck Chair", "Rattan Plant Stand", "Glass Hurricane Lamp",
        "Stoneware Bird Bath", "Bamboo Wind Chime", "Metal Fire Bowl", "Teak Garden Bench",
        "Ceramic Outdoor Vase", "Cotton Hammock", "Wooden Bird House", "Rattan Cocoon Chair",
        "Glass Outdoor Lantern", "Stoneware Plant Saucer", "Metal Garden Stake",
        "Teak Side Table", "Canvas Storage Bag",
    ],
    "Office": [
        "Oak Desk Organiser", "Metal Letter Tray", "Linen Document Folder", "Ceramic Pen Pot",
        "Wooden Monitor Stand", "Brass Desk Lamp", "Cotton Desk Pad", "Glass Paperweight",
        "Leather Notebook Cover", "Bamboo File Rack", "Metal Bookend", "Oak Pen Holder",
        "Linen Cable Pouch", "Ceramic Desk Tray", "Wooden Drawer Divider",
        "Brass Paper Clip Tray", "Cotton Stool Cushion", "Glass Desk Tidy",
        "Leather Desk Mat", "Bamboo Desk Shelf",
    ],
    "Decor": [
        "Recycled Glass Vase", "Ceramic Bud Vase", "Brass Wall Hook", "Marble Coaster Set",
        "Scented Candle", "Woven Wall Hanging", "Glass Candle Holder", "Stoneware Sculpture",
        "Metal Picture Frame", "Oak Photo Frame", "Ceramic Incense Holder",
        "Linen Table Centrepiece", "Brass Trinket Dish", "Marble Bookend", "Glass Cloche",
        "Rattan Mirror", "Stoneware Vase", "Metal Wall Clock", "Wooden Bowl",
        "Ceramic Ornament",
    ],
}

PRICE_BANDS = {
    "Kitchen": (8, 48),
    "Bathroom": (10, 65),
    "Lighting": (24, 140),
    "Storage": (10, 75),
    "Textiles": (12, 95),
    "Outdoor": (14, 160),
    "Office": (8, 58),
    "Decor": (6, 85),
}

OPTION_VALUES = {
    "Colour": ["Sage", "Black", "Oat"],
    "Size": ["Small", "Large"],
}

# Price styles deliberately found in the three supplier files.
PRICE_STYLES = [
    ("pound", lambda p: f"£{p:.2f}"),
    ("plain", lambda p: f"{p:.2f}"),
    ("gbp_prefix", lambda p: f"GBP {p:.2f}"),
    ("comma_decimal", lambda p: f"{p:.2f}".replace(".", ",")),
    ("pound_space", lambda p: f"£ {p:.2f}"),
    ("one_decimal", lambda p: f"{p:.1f}"),
    ("gbp_suffix", lambda p: f"{p:.2f} GBP"),
    ("no_decimals", lambda p: f"£{p:.0f}"),
    ("poa", lambda p: "POA"),
]


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class Product:
    sku: str
    parent_sku: str
    product_name: str
    base_name: str
    brand: str
    brand_code: str
    category: str
    category_code: str
    price: Decimal
    image_url: str
    barcode: str
    status: str
    option_name: str
    option_value: str
    source_file: str = ""
    source_row: int = 0
    source_sku_raw: str = ""
    # Defect markers, set before the raw files are written.
    sku_style: str = "clean"
    price_style: str = "pound"
    image_state: str = "valid"          # valid | missing | broken
    barcode_state: str = "valid"        # valid | invalid
    title_state: str = "clean"          # clean | missing_option
    category_state: str = "clean"       # clean | mismatch | missing
    brand_state: str = "clean"          # clean | missing
    price_state: str = "clean"          # clean | missing
    status_state: str = "active"        # active | discontinued
    whitespace_state: str = "clean"     # clean | messy
    duplicate_source: bool = False
    duplicate_title_group: int = 0


def ean13(body: str) -> str:
    """Return an EAN-13 check digit for a 12-digit body."""
    total = 0
    for i, ch in enumerate(reversed(body)):
        total += int(ch) * (3 if i % 2 == 0 else 1)
    return str((10 - total % 10) % 10)


def make_barcode(seq: int) -> str:
    body = f"506{seq:09d}"[:12]
    return body + ean13(body)


def slugify(text: str) -> str:
    text = text.lower().replace("&", "and")
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")


def money(value: float) -> Decimal:
    return Decimal(str(round(value, 2)))


def smart_title(text: str) -> str:
    small = {"and", "of", "with", "the", "for", "in", "on", "at", "by", "to"}
    words = text.split()
    built = []
    for i, word in enumerate(words):
        if i > 0 and word.lower() in small:
            built.append(word.lower())
        else:
            built.append(word[:1].upper() + word[1:].lower() if word.isupper() else word[:1].upper() + word[1:])
    return " ".join(built)


def build_master() -> list[Product]:
    """Create 220 parent products and expand 20 of them into 50 variant SKUs."""
    parents: list[dict] = []
    seq = 0

    # 160 first-brand products: 20 names per category.
    for ci, (category, cat_code) in enumerate(CATEGORIES):
        for ni, name in enumerate(BASE_NAMES[category]):
            brand, brand_code = BRANDS[(ni + ci) % len(BRANDS)]
            seq += 1
            parents.append({
                "base_name": name,
                "brand": brand,
                "brand_code": brand_code,
                "category": category,
                "category_code": cat_code,
                "parent_sku": f"{brand_code}-{cat_code}-{seq:04d}",
                "duplicate_source": False,
            })

    # 60 second-brand products, so the catalogue looks like a multi-brand retailer.
    for i in range(60):
        source = parents[i]
        brand_index = [b[0] for b in BRANDS].index(source["brand"])
        brand, brand_code = BRANDS[(brand_index + 1) % len(BRANDS)]
        seq += 1
        parents.append({
            "base_name": f"{BRAND_LINES[brand]} {source['base_name']}",
            "brand": brand,
            "brand_code": brand_code,
            "category": source["category"],
            "category_code": source["category_code"],
            "parent_sku": f"{brand_code}-{source['category_code']}-{seq:04d}",
            "duplicate_source": True,
        })

    # Choose 20 parents to expand into variants: 10 with three colours, 10 with two sizes.
    variant_parent_indices = list(range(4, 220, 11))[:20]
    variant_parents = {i: ("Colour" if n < 10 else "Size") for n, i in enumerate(variant_parent_indices)}

    products: list[Product] = []
    barcode_seq = 1
    for index, parent in enumerate(parents):
        category = parent["category"]
        low, high = PRICE_BANDS[category]
        base_price = money(rng.uniform(low, high))

        if index in variant_parents:
            option_name = variant_parents[index]
            for option_value in OPTION_VALUES[option_name]:
                price = base_price
                if option_name == "Size" and option_value == "Large":
                    price = money(float(base_price) + rng.uniform(3, 12))
                sku = f"{parent['parent_sku']}-{option_value[:3].upper()}"
                products.append(Product(
                    sku=sku,
                    parent_sku=parent["parent_sku"],
                    product_name=f"{parent['base_name']} — {option_value}",
                    base_name=parent["base_name"],
                    brand=parent["brand"],
                    brand_code=parent["brand_code"],
                    category=category,
                    category_code=parent["category_code"],
                    price=price,
                    image_url=f"https://cdn.example.com/{slugify(parent['brand'])}/{sku.lower()}.jpg",
                    barcode=make_barcode(barcode_seq),
                    status="active",
                    option_name=option_name,
                    option_value=option_value,
                ))
                barcode_seq += 1
        else:
            products.append(Product(
                sku=parent["parent_sku"],
                parent_sku="",
                product_name=parent["base_name"],
                base_name=parent["base_name"],
                brand=parent["brand"],
                brand_code=parent["brand_code"],
                category=category,
                category_code=parent["category_code"],
                price=base_price,
                image_url=f"https://cdn.example.com/{slugify(parent['brand'])}/{parent['parent_sku'].lower()}.jpg",
                barcode=make_barcode(barcode_seq),
                status="active",
                option_name="",
                option_value="",
            ))
            barcode_seq += 1

    assert len(products) == 250, len(products)
    return products


# ---------------------------------------------------------------------------
# Defect assignment
# ---------------------------------------------------------------------------

def split_pool(start: int, end: int) -> list[int]:
    return list(range(start, end))


def take(pool: list[int], n: int, *, from_end: bool = False) -> list[int]:
    chosen = []
    for _ in range(n):
        chosen.append(pool.pop(-1 if from_end else 0))
    return chosen


def assign_defects(products: list[Product]) -> dict:
    pools = {
        "A": split_pool(0, 100),
        "B": split_pool(100, 190),
        "C": split_pool(190, 250),
    }
    # Six repeated rows in each supplier file: 18 duplicate rows in total.
    # Use the end of each pool for duplicates so the main defect picks are spread.
    duplicate_indices = (
        take(pools["A"], 6, from_end=True)
        + take(pools["B"], 6, from_end=True)
        + take(pools["C"], 6, from_end=True)
    )
    for index in duplicate_indices:
        products[index].duplicate_source = True

    sku_styles = [
        ("lower", lambda s: s.lower()),
        ("underscore", lambda s: s.replace("-", "_")),
        ("space", lambda s: s.replace("-", " ")),
        ("dot", lambda s: s.replace("-", ".")),
        ("double_hyphen", lambda s: s.replace("-", "--")),
        ("slash_variant", lambda s: s.replace("-", "/", 1) if "-" in s else s),
        ("trailing_space", lambda s: s + " "),
        ("mixed", lambda s: s.lower().replace("-", "_")),
    ]
    sku_assignments = []
    style_cursor = 0
    for file_key, count in (("A", 4), ("B", 4), ("C", 4)):
        for index in take(pools[file_key], count):
            style_name = sku_styles[style_cursor % len(sku_styles)][0]
            products[index].sku_style = style_name
            sku_assignments.append((index, style_name))
            style_cursor += 1

    for file_key, count in (("A", 4), ("B", 5), ("C", 5)):
        for index in take(pools[file_key], count):
            products[index].image_state = "missing"
    for file_key, count in (("A", 2), ("B", 3), ("C", 2)):
        for index in take(pools[file_key], count):
            products[index].image_state = "broken"

    for file_key, count in (("A", 2), ("B", 2), ("C", 1)):
        for index in take(pools[file_key], count):
            products[index].category_state = "mismatch"
    for file_key, count in (("A", 1), ("B", 1), ("C", 2)):
        for index in take(pools[file_key], count):
            products[index].category_state = "missing"

    for file_key, count in (("A", 1), ("B", 2), ("C", 1)):
        for index in take(pools[file_key], count):
            products[index].barcode_state = "invalid"
    for file_key, count in (("A", 1), ("B", 1), ("C", 1)):
        for index in take(pools[file_key], count):
            products[index].status_state = "discontinued"
    for file_key, count in (("A", 2), ("B", 2), ("C", 1)):
        for index in take(pools[file_key], count):
            products[index].price_state = "missing"
    for file_key, count in (("A", 1), ("B", 1), ("C", 1)):
        for index in take(pools[file_key], count):
            products[index].brand_state = "missing"

    # Six variant-title groups deliberately omit the option from the title.
    # Only variant parents with at least two rows are eligible.
    variant_groups: dict[str, list[int]] = defaultdict(list)
    for i, product in enumerate(products):
        if product.parent_sku:
            variant_groups[product.parent_sku].append(i)
    eligible = [indices for indices in variant_groups.values() if len(indices) >= 2]
    rng.shuffle(eligible)
    for group_no, indices in enumerate(eligible[:6], start=1):
        for index in indices:
            products[index].title_state = "missing_option"
            products[index].duplicate_title_group = group_no

    # Every fifth row gets messy whitespace/case.
    for i, product in enumerate(products):
        if i % 5 == 0:
            product.whitespace_state = "messy"

    # Price styles preserve the exact source value. Rounded formats are used
    # only where the price is already exact at that precision, so cleaning
    # never invents or discards pence.
    preserving_styles = [
        "pound", "plain", "gbp_prefix", "comma_decimal", "pound_space", "gbp_suffix",
    ]
    whole_used = False
    tenth_used = False
    style_cursor = 0
    for product in products:
        if product.price_state == "missing":
            product.price_style = "poa"
            continue
        cents = int((product.price * 100).to_integral_value())
        if not whole_used and cents % 100 == 0:
            product.price_style = "no_decimals"
            whole_used = True
        elif not tenth_used and cents % 10 == 0:
            product.price_style = "one_decimal"
            tenth_used = True
        else:
            product.price_style = preserving_styles[style_cursor % len(preserving_styles)]
            style_cursor += 1

    # Guarantee that the no-decimal and one-decimal formats appear even if the
    # random prices happen not to include an exact case.
    if not whole_used:
        candidate = next(p for p in products if p.price_state != "missing")
        candidate.price = Decimal(int(candidate.price))
        candidate.price_style = "no_decimals"
    if not tenth_used:
        candidate = next(
            p for p in products
            if p.price_state != "missing" and p.price_style != "no_decimals"
        )
        candidate.price = candidate.price.quantize(Decimal("0.1"))
        if candidate.price == candidate.price.to_integral_value():
            candidate.price += Decimal("0.1")
        candidate.price_style = "one_decimal"

    return {
        "duplicate_indices": duplicate_indices,
        "sku_assignments": sku_assignments,
        "variant_title_groups": [indices for indices in eligible[:6]],
    }


# ---------------------------------------------------------------------------
# Raw file construction
# ---------------------------------------------------------------------------

def raw_sku(product: Product) -> str:
    sku = product.sku
    style = product.sku_style
    if style == "lower":
        return sku.lower()
    if style == "underscore":
        return sku.replace("-", "_")
    if style == "space":
        return sku.replace("-", " ")
    if style == "dot":
        return sku.replace("-", ".")
    if style == "double_hyphen":
        return sku.replace("-", "--")
    if style == "slash_variant" and "-" in sku:
        head, tail = sku.rsplit("-", 1)
        return f"{head}/{tail}"
    if style == "trailing_space":
        return sku + " "
    if style == "mixed":
        return sku.lower().replace("-", "_")
    return sku


def raw_price(product: Product) -> str:
    style = next(fn for name, fn in PRICE_STYLES if name == product.price_style)
    return style(product.price)


def raw_name(product: Product) -> str:
    if product.title_state == "missing_option":
        name = product.base_name
    else:
        name = product.product_name
    if product.whitespace_state == "messy":
        name = f"  {name}  "
    return name


def raw_brand(product: Product) -> str:
    if product.brand_state == "missing":
        return ""
    if product.whitespace_state == "messy":
        return product.brand.lower()
    return product.brand


def raw_category(product: Product) -> str:
    if product.category_state == "missing":
        return ""
    if product.category_state == "mismatch":
        other = [c for c, _ in CATEGORIES if c != product.category]
        return rng.choice(other)
    if product.whitespace_state == "messy":
        return product.category.lower()
    return product.category


def raw_product_type(product: Product) -> str:
    if product.category_state == "missing":
        return ""
    return product.category


def raw_image(product: Product) -> str:
    if product.image_state == "missing":
        return ""
    if product.image_state == "broken":
        return f"https://cdn.example.com/broken/{product.sku.lower()}.jpg"
    return product.image_url


def raw_barcode(product: Product) -> str:
    if product.barcode_state == "invalid":
        # Change the check digit by one. The original barcode is valid, so a
        # different final digit is guaranteed to fail the GTIN check.
        wrong = str((int(product.barcode[-1]) + 1) % 10)
        return product.barcode[:-1] + wrong
    return product.barcode


def raw_status(product: Product) -> str:
    if product.status_state == "discontinued":
        return "Discontinued"
    return "Active"


def raw_row(product: Product) -> dict:
    return {
        "sku": raw_sku(product),
        "product_name": raw_name(product),
        "brand": raw_brand(product),
        "category": raw_category(product),
        "product_type": raw_product_type(product),
        "price": raw_price(product),
        "image_url": raw_image(product),
        "barcode": raw_barcode(product),
        "status": raw_status(product),
        "parent_sku": product.parent_sku,
        "option_name": product.option_name,
        "option_value": product.option_value,
    }


def write_supplier_a(rows: list[dict]) -> None:
    path = RAW / "supplier-a.csv"
    headers = [
        "SKU", "Product Name", "Brand", "Category", "Product Type", "Price",
        "Image URL", "Barcode", "Status", "Parent Code", "Option", "Option Value",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "SKU": row["sku"],
                "Product Name": row["product_name"],
                "Brand": row["brand"],
                "Category": row["category"],
                "Product Type": row["product_type"],
                "Price": row["price"],
                "Image URL": row["image_url"],
                "Barcode": row["barcode"],
                "Status": row["status"],
                "Parent Code": row["parent_sku"],
                "Option": row["option_name"],
                "Option Value": row["option_value"],
            })


def write_supplier_c(rows: list[dict]) -> None:
    path = RAW / "supplier-c.csv"
    headers = [
        "sku", "product_title", "brand", "category", "product_type", "price_gbp",
        "image_url", "barcode", "status", "parent_sku", "option_name", "option_value",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "sku": row["sku"],
                "product_title": row["product_name"],
                "brand": row["brand"],
                "category": row["category"],
                "product_type": row["product_type"],
                "price_gbp": row["price"],
                "image_url": row["image_url"],
                "barcode": row["barcode"],
                "status": row["status"],
                "parent_sku": row["parent_sku"],
                "option_name": row["option_name"],
                "option_value": row["option_value"],
            })


def write_supplier_b(rows: list[dict]) -> None:
    path = RAW / "supplier-b.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Products"

    # Two header rows with merged group headings, a realistic supplier layout.
    ws.merge_cells("A1:C1")
    ws.merge_cells("D1:E1")
    ws.merge_cells("F1:G1")
    ws.merge_cells("H1:I1")
    groups = ["Product details", "Classification", "Commercial", "Identifiers"]
    for cell, label in zip(("A1", "D1", "F1", "H1"), groups):
        ws[cell] = label
        ws[cell].font = Font(bold=True, color=OAT)
        ws[cell].fill = PatternFill("solid", fgColor=CHERRY)
        ws[cell].alignment = Alignment(horizontal="left", vertical="center")

    headers = [
        "Item Code", "Description", "Brand Name", "Department", "Product Type",
        "Unit Price (GBP)", "Image Link", "EAN", "Stock Status",
        "Parent SKU", "Option Name", "Option Value",
    ]
    # A1:I1 only covers the first nine columns; the variant fields sit below
    # the "Product details" group and are not merged into a group.
    for col, header in enumerate(headers, start=1):
        cell = ws.cell(row=2, column=col, value=header)
        cell.font = Font(bold=True, color=CHERRY)
        cell.fill = PatternFill("solid", fgColor="E6D4DF")
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    ws.row_dimensions[1].height = 24
    ws.row_dimensions[2].height = 32
    ws.freeze_panes = "A3"

    for row in rows:
        ws.append([
            row["sku"], row["product_name"], row["brand"], row["category"],
            row["product_type"], row["price"], row["image_url"], row["barcode"],
            row["status"], row["parent_sku"], row["option_name"], row["option_value"],
        ])

    widths = [18, 42, 22, 18, 16, 16, 44, 18, 16, 18, 14, 16]
    for i, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width
    for row in ws.iter_rows(min_row=3, max_row=ws.max_row, min_col=1, max_col=12):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=False)
    ws.auto_filter.ref = f"A2:L{ws.max_row}"

    notes = wb.create_sheet("Read me")
    notes["A1"] = "Supplier B — product file"
    notes["A1"].font = Font(bold=True, size=16, color=CHERRY)
    notes["A3"] = "This sheet is a synthetic sample for a portfolio case study."
    notes["A4"] = "The Products sheet uses two header rows and merged group headings."
    notes["A5"] = "Prices are in GBP. EAN values should be treated as text."
    notes.column_dimensions["A"].width = 92

    wb.save(path)


def build_raw_rows(products: list[Product]) -> dict[str, list[dict]]:
    # Split by the first 100 / next 90 / final 60 SKU rows.
    files = {
        "A": products[:100],
        "B": products[100:190],
        "C": products[190:250],
    }
    raw = {}
    for file_key, file_products in files.items():
        rows = [raw_row(product) for product in file_products]
        # Six repeated rows per file, one extra row each: 18 duplicate rows.
        originals = [i for i, p in enumerate(file_products) if p.duplicate_source]
        if len(originals) != 6:
            raise AssertionError(f"{file_key}: expected 6 duplicate source rows, found {len(originals)}")

        # One duplicate pair is complementary: one row has the image but no
        # barcode, the other has the barcode but no image. The merge should
        # keep both values and record where the filled field came from.
        merge_demo_index = None
        if file_key == "A":
            merge_demo_index = next(
                (
                    i for i in originals
                    if file_products[i].barcode_state != "invalid"
                    and file_products[i].image_state == "valid"
                    and file_products[i].price_state != "missing"
                    and file_products[i].brand_state != "missing"
                    and file_products[i].category_state == "clean"
                ),
                None,
            )

        for n, original_index in enumerate(originals):
            duplicate = dict(rows[original_index])
            if original_index == merge_demo_index:
                valid_barcode = rows[original_index]["barcode"]
                rows[original_index]["barcode"] = ""
                duplicate["image_url"] = ""
                duplicate["barcode"] = valid_barcode
            else:
                # Make the remaining duplicates complementary rather than
                # exact copies.
                variant = n % 3
                if variant == 0:
                    duplicate["image_url"] = ""
                elif variant == 1:
                    duplicate["price"] = PRICE_STYLES[(n + 2) % 8][1](file_products[original_index].price)
                else:
                    # Repeat the row with a padded title rather than a second
                    # SKU defect, so the SKU-format count reflects the 12
                    # deliberate source formats.
                    duplicate["product_name"] = f"  {duplicate['product_name']}  "
            rows.append(duplicate)
        rng.shuffle(rows)
        raw[file_key] = rows
    write_supplier_a(raw["A"])
    write_supplier_b(raw["B"])
    write_supplier_c(raw["C"])
    return raw


# ---------------------------------------------------------------------------
# Cleaning
# ---------------------------------------------------------------------------

HEADER_ALIASES = {
    "sku": {"sku", "item_code", "product_code", "code", "item_code_sku"},
    "product_name": {"product_name", "description", "product_title", "title"},
    "brand": {"brand", "brand_name", "vendor"},
    "category": {"category", "department", "product_category"},
    "product_type": {"product_type", "type", "category_type"},
    "price": {"price", "unit_price_gbp", "price_gbp", "unit_price"},
    "image_url": {"image_url", "image_link", "image", "image_src"},
    "barcode": {"barcode", "ean", "gtin"},
    "status": {"status", "stock_status", "state"},
    "parent_sku": {"parent_sku", "parent_code", "parent"},
    "option_name": {"option_name", "option", "variant_name"},
    "option_value": {"option_value", "variant", "variant_value"},
}


def normalise_header(value: str) -> str:
    value = str(value or "").strip().lower()
    value = re.sub(r"[^a-z0-9]+", "_", value)
    return value.strip("_")


def canonical_field(header: str) -> str | None:
    key = normalise_header(header)
    for canonical, aliases in HEADER_ALIASES.items():
        if key in aliases:
            return canonical
    return None


def clean_text(value) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\u00a0", " ")).strip()


def raw_text(value) -> str:
    """Preserve the source text, including leading/trailing whitespace."""
    return "" if value is None else str(value)


def normalise_sku(value: str) -> str:
    s = clean_text(value).upper()
    s = re.sub(r"[\s_./]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s


def parse_price(value: str) -> Decimal | None:
    s = clean_text(value).upper().replace("GBP", "").replace("£", "").strip()
    if s in {"", "POA", "N/A", "NA", "-", "—"}:
        return None
    if "," in s and "." not in s:
        s = s.replace(",", ".")
    else:
        s = s.replace(",", "")
    try:
        return Decimal(s).quantize(Decimal("0.01"))
    except InvalidOperation:
        return None


def valid_gtin(value: str) -> bool:
    digits = re.sub(r"\D", "", clean_text(value))
    if len(digits) not in {8, 12, 13, 14}:
        return False
    body, check = digits[:-1], int(digits[-1])
    total = 0
    for i, ch in enumerate(reversed(body)):
        total += int(ch) * (3 if i % 2 == 0 else 1)
    return (10 - total % 10) % 10 == check


def canonical_brand(value: str) -> str:
    text = clean_text(value)
    for brand, _ in BRANDS:
        if text.lower() == brand.lower():
            return brand
    return smart_title(text) if text else ""


def canonical_category(value: str) -> str:
    text = clean_text(value).lower()
    for category, _ in CATEGORIES:
        if text == category.lower():
            return category
    aliases = {
        "kitchenware": "Kitchen", "cookware": "Kitchen", "dining": "Kitchen",
        "bath": "Bathroom", "bathroom accessories": "Bathroom",
        "light": "Lighting", "lamps": "Lighting",
        "storage & organisation": "Storage", "organisation": "Storage",
        "textile": "Textiles", "soft furnishings": "Textiles",
        "garden": "Outdoor", "outdoor living": "Outdoor",
        "desk": "Office", "stationery": "Office",
        "home decor": "Decor", "accessories": "Decor",
    }
    return aliases.get(text, "")


def read_csv_supplier(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = []
        for row_number, row in enumerate(reader, start=2):
            mapped = {}
            for key, value in row.items():
                canonical = canonical_field(key)
                if canonical:
                    mapped[canonical] = value
            mapped["_source_file"] = path.name
            mapped["_source_row"] = row_number
            rows.append(mapped)
        return rows


def read_supplier_b(path: Path) -> list[dict]:
    wb = load_workbook(path, data_only=True)
    ws = wb["Products"]
    # Pick the header row with the most mapped columns in the first five rows.
    best_row, best_score = 2, -1
    for row_number in range(1, min(6, ws.max_row) + 1):
        values = [ws.cell(row=row_number, column=c).value for c in range(1, ws.max_column + 1)]
        score = sum(1 for value in values if canonical_field(value))
        if score > best_score:
            best_row, best_score = row_number, score
    headers = [ws.cell(row=best_row, column=c).value for c in range(1, ws.max_column + 1)]
    rows = []
    for row_number in range(best_row + 1, ws.max_row + 1):
        mapped = {}
        for col, header in enumerate(headers, start=1):
            canonical = canonical_field(header)
            if canonical:
                mapped[canonical] = ws.cell(row=row_number, column=col).value
        if not clean_text(mapped.get("sku")):
            continue
        mapped["_source_file"] = path.name
        mapped["_source_row"] = row_number
        rows.append(mapped)
    return rows


def merge_duplicates(rows: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
    """Group by normalised SKU, merge fields, and return cleaned rows + logs."""
    groups: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        groups[normalise_sku(row.get("sku", ""))].append(row)

    cleaned = []
    duplicate_log = []
    change_log = []
    for sku, group in groups.items():
        if not sku:
            continue
        # Prefer the row with the most non-empty fields, then the earliest source row.
        group_sorted = sorted(
            group,
            key=lambda r: (-sum(1 for v in r.values() if clean_text(v)), r["_source_row"]),
        )
        base = dict(group_sorted[0])
        # Keep the original SKU text for the change log before normalising it.
        base["_source_sku"] = base.get("sku", "")
        base["sku"] = sku
        merged_from = [r["_source_row"] for r in group_sorted]
        if len(group) > 1:
            duplicate_log.append({
                "sku": sku,
                "source_file": base["_source_file"],
                "source_rows": merged_from,
                "rows_removed": len(group) - 1,
                "rule": "Group by normalised SKU; keep one row and merge non-empty fields.",
            })
            # Fill blanks from the other rows.
            filled_fields = []
            for other in group_sorted[1:]:
                for key, value in other.items():
                    if key.startswith("_"):
                        continue
                    if not clean_text(base.get(key)) and clean_text(value):
                        base[key] = value
                        filled_fields.append(key)
                        change_log.append({
                            "sku": sku,
                            "field": key,
                            "before": "",
                            "after": clean_text(value),
                            "rule": "Duplicate SKU merge: filled a blank field from a duplicate row.",
                            "source_file": base["_source_file"],
                            "source_row": other["_source_row"],
                        })
            duplicate_log[-1]["merged_fields"] = sorted(set(filled_fields))
        base["_merged_rows"] = len(group)
        cleaned.append(base)

    cleaned.sort(key=lambda r: r["sku"])
    return cleaned, duplicate_log, change_log


def clean_catalogue(products: list[Product]) -> tuple[list[dict], dict]:
    raw_a = read_csv_supplier(RAW / "supplier-a.csv")
    raw_b = read_supplier_b(RAW / "supplier-b.xlsx")
    raw_c = read_csv_supplier(RAW / "supplier-c.csv")
    all_raw = raw_a + raw_b + raw_c

    cleaned, duplicate_log, duplicate_changes = merge_duplicates(all_raw)

    # Count duplicate titles before disambiguation.
    title_counts = Counter(clean_text(r.get("product_name", "")) for r in cleaned if clean_text(r.get("product_name", "")))
    duplicate_title_count = sum(1 for title, count in title_counts.items() if count > 1)

    changes = list(duplicate_changes)
    review = []
    final_rows = []

    for row in cleaned:
        sku = row["sku"]
        raw_sku_unstripped = raw_text(row.get("_source_sku", row.get("sku", "")))
        raw_sku_text = clean_text(raw_sku_unstripped)
        raw_name_unstripped = raw_text(row.get("product_name", ""))
        raw_name_text = clean_text(raw_name_unstripped)
        raw_brand_unstripped = raw_text(row.get("brand", ""))
        raw_brand_text = clean_text(raw_brand_unstripped)
        raw_category_unstripped = raw_text(row.get("category", ""))
        raw_category_text = clean_text(raw_category_unstripped)
        raw_type_text = clean_text(row.get("product_type", ""))
        raw_price_text = clean_text(row.get("price", ""))
        raw_image_text = clean_text(row.get("image_url", ""))
        raw_barcode_text = clean_text(row.get("barcode", ""))
        raw_status_text = clean_text(row.get("status", ""))
        raw_parent_text = clean_text(row.get("parent_sku", ""))
        raw_option_name = clean_text(row.get("option_name", ""))
        raw_option_value = clean_text(row.get("option_value", ""))

        flags: list[str] = []
        whitespace_touched = False

        # SKU format: compare the normalised SKU with the raw text.
        sku_format_needed = (
            normalise_sku(raw_sku_text) != raw_sku_text
            or raw_sku_unstripped != raw_sku_text
        )
        if sku_format_needed:
            flags.append("sku_format_normalised")
            if raw_sku_unstripped != raw_sku_text:
                whitespace_touched = True
            changes.append({
                "sku": sku, "field": "SKU", "before": raw_sku_unstripped, "after": sku,
                "rule": "Uppercase; replace spaces, underscores, dots and slashes with hyphens; collapse repeats; trim.",
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })

        # Price.
        price = parse_price(raw_price_text)
        if price is None:
            flags.append("missing_price")
            review.append({
                "sku": sku, "issue": "Missing or non-numeric price",
                "source_value": raw_price_text, "cleaned_value": "",
                "rule": "POA and blank values are not guessed.",
                "next_action": "Ask the supplier for a firm GBP price.",
                "blocking": True,
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })
        elif f"{price:.2f}" != raw_price_text:
            changes.append({
                "sku": sku, "field": "Price", "before": raw_price_text, "after": f"{price:.2f}",
                "rule": "Parse GBP formats; standardise to two decimal places.",
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })

        # Image.
        image_status = "valid"
        image_url = raw_image_text
        if not raw_image_text:
            image_status = "missing"
            flags.append("missing_image")
            review.append({
                "sku": sku, "issue": "Missing image link",
                "source_value": "", "cleaned_value": "",
                "rule": "No image URL was present.",
                "next_action": "Request a usable image URL or image file from the supplier.",
                "blocking": True,
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })
        elif "/broken/" in raw_image_text.lower() or "broken" in raw_image_text.lower():
            image_status = "broken"
            image_url = ""
            flags.append("broken_image")
            review.append({
                "sku": sku, "issue": "Broken image link",
                "source_value": raw_image_text, "cleaned_value": "",
                "rule": "The source URL is a known broken path in this sample.",
                "next_action": "Request a replacement image URL.",
                "blocking": True,
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })

        # Barcode.
        barcode = re.sub(r"\D", "", raw_barcode_text)
        barcode_status = "valid"
        if not barcode:
            barcode_status = "missing"
            flags.append("missing_barcode")
            review.append({
                "sku": sku, "issue": "Missing barcode",
                "source_value": "", "cleaned_value": "",
                "rule": "No barcode was present.",
                "next_action": "Request the product EAN/GTIN.",
                "blocking": True,
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })
        elif not valid_gtin(barcode):
            barcode_status = "invalid"
            flags.append("invalid_barcode")
            review.append({
                "sku": sku, "issue": "Invalid barcode",
                "source_value": raw_barcode_text, "cleaned_value": "",
                "rule": "GTIN length and check digit validation failed.",
                "next_action": "Ask the supplier to confirm the correct EAN/GTIN.",
                "blocking": True,
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })
            barcode = ""

        # Brand.
        brand = canonical_brand(raw_brand_text)
        if not brand:
            flags.append("missing_brand")
            review.append({
                "sku": sku, "issue": "Missing brand",
                "source_value": "", "cleaned_value": "",
                "rule": "No brand value was present.",
                "next_action": "Confirm the brand before import.",
                "blocking": True,
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })
        elif raw_brand_unstripped != brand:
            if (
                raw_brand_unstripped != raw_brand_text
                or (raw_brand_text != brand and raw_brand_text.lower() == brand.lower())
            ):
                whitespace_touched = True
            changes.append({
                "sku": sku, "field": "Brand", "before": raw_brand_unstripped, "after": brand,
                "rule": "Trim and collapse whitespace; restore the canonical brand spelling.",
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })

        # Category.
        true_category = canonical_category(raw_type_text)
        raw_category = canonical_category(raw_category_text)
        category = true_category or raw_category
        category_status = "valid"
        if not category:
            category_status = "missing"
            flags.append("missing_category")
            review.append({
                "sku": sku, "issue": "Missing category",
                "source_value": raw_category_text, "cleaned_value": "",
                "rule": "No usable category or product type was present.",
                "next_action": "Confirm the destination category.",
                "blocking": True,
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })
        elif true_category and not raw_category:
            category_status = "filled"
            flags.append("category_filled_from_type")
            changes.append({
                "sku": sku, "field": "Category", "before": raw_category_unstripped, "after": true_category,
                "rule": "Category was blank; use the consistent product type as the category.",
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })
        elif true_category and raw_category and raw_category != true_category:
            category_status = "corrected"
            flags.append("category_mismatch_corrected")
            changes.append({
                "sku": sku, "field": "Category", "before": raw_category_unstripped, "after": true_category,
                "rule": "Use the product type as the category when the supplier department conflicts.",
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })
        elif category and raw_category_unstripped != category:
            if (
                raw_category_unstripped != raw_category_text
                or (raw_category_text != category and raw_category_text.lower() == category.lower())
            ):
                whitespace_touched = True
            changes.append({
                "sku": sku, "field": "Category", "before": raw_category_unstripped, "after": category,
                "rule": "Trim and collapse whitespace; restore the canonical category spelling.",
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })

        # Product title.
        if raw_name_unstripped != raw_name_text:
            whitespace_touched = True
        title = smart_title(raw_name_text)
        if title_counts.get(raw_name_text, 0) > 1:
            if raw_option_value:
                title = f"{title} — {smart_title(raw_option_value)}"
            elif brand:
                title = f"{title} ({brand})"
            else:
                title = f"{title} ({sku})"
            flags.append("duplicate_title_resolved")
            review.append({
                "sku": sku, "issue": "Duplicate product title",
                "source_value": raw_name_text, "cleaned_value": title,
                "rule": "Append the option value (or brand) to make the title unique.",
                "next_action": "Check the disambiguated title against the supplier description.",
                "blocking": False,
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })
        if title != raw_name_text:
            changes.append({
                "sku": sku, "field": "Product name", "before": raw_name_unstripped, "after": title,
                "rule": "Trim and collapse whitespace; restore title case; disambiguate duplicate titles.",
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })

        # Status.
        status_text = raw_status_text.lower()
        if status_text in {"discontinued", "d", "off", "inactive", "no"}:
            status = "discontinued"
            flags.append("discontinued")
        else:
            status = "active"

        # Parent / option.
        parent_sku = normalise_sku(raw_parent_text) if raw_parent_text else ""
        option_name = smart_title(raw_option_name)
        option_value = smart_title(raw_option_value)
        if parent_sku and not option_name:
            flags.append("variant_option_missing")
            review.append({
                "sku": sku, "issue": "Variant option missing",
                "source_value": "", "cleaned_value": "",
                "rule": "A parent SKU exists but no option name was supplied.",
                "next_action": "Confirm the option name and value.",
                "blocking": True,
                "source_file": row["_source_file"], "source_row": row["_source_row"],
            })

        # Blocking flags determine the import status.
        if whitespace_touched:
            flags.append("whitespace_or_case_normalised")
        blocking = {"missing_price", "missing_image", "broken_image", "missing_barcode",
                    "invalid_barcode", "missing_brand", "missing_category", "variant_option_missing"}
        if status == "discontinued":
            import_status = "Discontinued"
        elif blocking & set(flags):
            import_status = "Review"
        else:
            import_status = "Ready"

        final_rows.append({
            "sku": sku,
            "parent_sku": parent_sku,
            "product_name": title,
            "brand": brand,
            "category": category,
            "category_status": category_status,
            "price_gbp": f"{price:.2f}" if price is not None else "",
            "price_status": "missing" if price is None else "valid",
            "image_url": image_url,
            "image_status": image_status,
            "barcode": barcode,
            "barcode_status": barcode_status,
            "status": status,
            "option_name": option_name,
            "option_value": option_value,
            "import_status": import_status,
            "review_flags": "; ".join(flags),
            "source_file": row["_source_file"],
            "source_row": row["_source_row"],
            "source_sku": raw_sku_text,
            "source_price": raw_price_text,
        })

    # Validation against the synthetic master.
    by_sku = {p.sku: p for p in products}
    cleaned_skus = {r["sku"] for r in final_rows}
    if cleaned_skus != set(by_sku):
        missing = sorted(set(by_sku) - cleaned_skus)[:5]
        extra = sorted(cleaned_skus - set(by_sku))[:5]
        raise AssertionError(f"SKU mismatch. Missing: {missing}. Extra: {extra}.")

    summary = {
        "unique_skus": len(final_rows),
        "raw_rows": len(all_raw),
        "duplicate_rows_removed": sum(item["rows_removed"] for item in duplicate_log),
        "duplicate_sku_groups": len(duplicate_log),
        "duplicate_title_groups": duplicate_title_count,
        "duplicate_title_rows": sum(1 for r in final_rows if "duplicate_title_resolved" in r["review_flags"]),
        "sku_formats_normalised": sum(1 for r in final_rows if "sku_format_normalised" in r["review_flags"]),
        "price_formats": len({p.price_style for p in products}),
        "missing_prices": sum(1 for r in final_rows if r["price_status"] == "missing"),
        "missing_images": sum(1 for r in final_rows if r["image_status"] == "missing"),
        "broken_images": sum(1 for r in final_rows if r["image_status"] == "broken"),
        "category_mismatches": sum(1 for r in final_rows if r["category_status"] == "corrected"),
        "missing_categories": sum(1 for r in final_rows if r["category_status"] == "missing"),
        "categories_filled_from_type": sum(1 for r in final_rows if "category_filled_from_type" in r["review_flags"]),
        "invalid_barcodes": sum(1 for r in final_rows if r["barcode_status"] == "invalid"),
        "missing_barcodes": sum(1 for r in final_rows if r["barcode_status"] == "missing"),
        "missing_brands": sum(1 for r in final_rows if "missing_brand" in r["review_flags"]),
        "discontinued": sum(1 for r in final_rows if r["status"] == "discontinued"),
        "ready": sum(1 for r in final_rows if r["import_status"] == "Ready"),
        "review": sum(1 for r in final_rows if r["import_status"] == "Review"),
        "review_entries": len(review),
        "blocking_review_entries": sum(1 for r in review if r["blocking"]),
        "change_entries": len(changes),
        "whitespace_case_rows": sum(1 for r in final_rows if "whitespace_or_case_normalised" in r["review_flags"]),
    }

    validation = validate_catalogue(products, final_rows)
    return final_rows, {
        "summary": summary,
        "review": review,
        "changes": changes,
        "duplicates": duplicate_log,
        "validation": validation,
        "raw_counts": {"A": len(raw_a), "B": len(raw_b), "C": len(raw_c)},
    }


def validate_catalogue(products: list[Product], rows: list[dict]) -> dict:
    """Compare every cleaned row with the synthetic master and check safety rules."""
    by_sku = {p.sku: p for p in products}
    seen: set[str] = set()
    failures: list[str] = []
    valid_barcodes = 0
    blocking_flags = {
        "missing_price", "missing_image", "broken_image", "missing_barcode",
        "invalid_barcode", "missing_brand", "missing_category", "variant_option_missing",
    }

    for row in rows:
        sku = row["sku"]
        if sku in seen:
            failures.append(f"{sku}: duplicate SKU in cleaned output")
        seen.add(sku)
        product = by_sku.get(sku)
        if product is None:
            failures.append(f"{sku}: not in synthetic master")
            continue

        expected = {
            "product_name": smart_title(product.product_name),
            "brand": "" if product.brand_state == "missing" else product.brand,
            "category": "" if product.category_state == "missing" else product.category,
            "price_gbp": "" if product.price_state == "missing" else f"{product.price:.2f}",
            "barcode": "" if product.barcode_state in {"invalid", "missing"} else product.barcode,
            "status": "discontinued" if product.status_state == "discontinued" else "active",
            "parent_sku": normalise_sku(product.parent_sku) if product.parent_sku else "",
            "option_name": smart_title(product.option_name),
            "option_value": smart_title(product.option_value),
        }
        for field, value in expected.items():
            if row[field] != value:
                failures.append(f"{sku}: {field} expected {value!r}, found {row[field]!r}")

        expected_image_status = product.image_state if product.image_state in {"missing", "broken"} else "valid"
        expected_image_url = "" if product.image_state in {"missing", "broken"} else product.image_url
        if row["image_status"] != expected_image_status:
            failures.append(f"{sku}: image status expected {expected_image_status!r}, found {row['image_status']!r}")
        if row["image_url"] != expected_image_url:
            failures.append(f"{sku}: image URL expected {expected_image_url!r}, found {row['image_url']!r}")

        expected_barcode_status = "invalid" if product.barcode_state == "invalid" else "valid"
        if row["barcode_status"] != expected_barcode_status:
            failures.append(f"{sku}: barcode status expected {expected_barcode_status!r}, found {row['barcode_status']!r}")
        if row["barcode"]:
            if valid_gtin(row["barcode"]):
                valid_barcodes += 1
            else:
                failures.append(f"{sku}: cleaned barcode does not pass GTIN validation")

        if row["price_gbp"] and not re.fullmatch(r"\d+\.\d{2}", row["price_gbp"]):
            failures.append(f"{sku}: price {row['price_gbp']!r} is not two decimal places")

        expected_import = "Discontinued" if row["status"] == "discontinued" else (
            "Review" if blocking_flags & set(row["review_flags"].split("; ")) else "Ready"
        )
        if row["import_status"] != expected_import:
            failures.append(f"{sku}: import status expected {expected_import!r}, found {row['import_status']!r}")
        if row["import_status"] == "Ready":
            for field in ("price_gbp", "image_url", "barcode", "brand", "category"):
                if not row[field]:
                    failures.append(f"{sku}: Ready row has a blank {field}")

    missing = sorted(set(by_sku) - seen)
    extra = sorted(seen - set(by_sku))
    if missing:
        failures.append(f"Missing from output: {missing[:5]}")
    if extra:
        failures.append(f"Unexpected in output: {extra[:5]}")

    titles = [row["product_name"] for row in rows]
    barcodes = [row["barcode"] for row in rows if row["barcode"]]
    result = {
        "master_skus": len(by_sku),
        "output_skus": len(rows),
        "unique_titles": len(set(titles)),
        "duplicate_titles_after_cleaning": len(titles) - len(set(titles)),
        "valid_barcodes": valid_barcodes,
        "empty_barcodes": sum(1 for row in rows if not row["barcode"]),
        "unique_nonempty_barcodes": len(set(barcodes)),
        "ready_rows": sum(1 for row in rows if row["import_status"] == "Ready"),
        "review_rows": sum(1 for row in rows if row["import_status"] == "Review"),
        "discontinued_rows": sum(1 for row in rows if row["import_status"] == "Discontinued"),
        "failures": failures,
    }
    if failures:
        raise AssertionError("Catalogue validation failed: " + " | ".join(failures[:10]))
    return result


# ---------------------------------------------------------------------------
# Outputs
# ---------------------------------------------------------------------------

def write_csv(path: Path, rows: list[dict], headers: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def shopify_rows(rows: list[dict]) -> list[dict]:
    """Build a Shopify product CSV with one row per variant.

    Product-level fields appear only on the first row of each handle; later
    rows carry the variant fields. This is the shape Shopify expects when
    several variants belong to one product.
    """
    groups: dict[str, list[dict]] = {}
    order: list[str] = []
    for row in rows:
        if row["status"] == "discontinued":
            continue
        key = row["parent_sku"] or row["sku"]
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(row)

    out = []
    used_handles: set[str] = set()
    for key in order:
        group = groups[key]
        if not group:
            continue
        first = group[0]
        is_variant_group = bool(first["parent_sku"])

        parent_title = first["product_name"]
        if is_variant_group and first["option_value"]:
            suffix = f" — {first['option_value']}"
            if parent_title.endswith(suffix):
                parent_title = parent_title[: -len(suffix)]

        base_handle = slugify(f"{first['brand']} {parent_title}")[:80] or slugify(first["sku"])
        handle = base_handle
        suffix_no = 2
        while handle in used_handles:
            handle = f"{base_handle}-{suffix_no}"[:80]
            suffix_no += 1
        used_handles.add(handle)

        group_ready = all(r["import_status"] == "Ready" for r in group)
        product_image = next((r["image_url"] for r in group if r["image_url"]), "")
        product_status = "active" if group_ready else "draft"
        published = "TRUE" if group_ready else "FALSE"

        for index, row in enumerate(group):
            is_first = index == 0
            out.append({
                "Handle": handle,
                "Title": parent_title if is_first else "",
                "Body (HTML)": (
                    f"<p>{parent_title} by {first['brand'] or 'brand to confirm'}.</p>"
                    f"<p>Category: {first['category'] or 'to confirm'}.</p>"
                ) if is_first else "",
                "Vendor": first["brand"] if is_first else "",
                "Product Category": first["category"] if is_first else "",
                "Type": first["category"] if is_first else "",
                "Tags": f"{first['brand']}, {first['category']}".strip(", ") if is_first else "",
                "Published": published if is_first else "",
                "Option1 Name": (row["option_name"] or "Title") if is_first or is_variant_group else "Title",
                "Option1 Value": (row["option_value"] or "Default Title") if is_first or is_variant_group else "Default Title",
                "Variant SKU": row["sku"],
                "Variant Grams": "",
                "Variant Inventory Tracker": "shopify",
                "Variant Inventory Qty": "0",
                "Variant Inventory Policy": "deny",
                "Variant Fulfillment Service": "manual",
                "Variant Price": row["price_gbp"],
                "Variant Compare At Price": "",
                "Variant Requires Shipping": "TRUE",
                "Variant Taxable": "TRUE",
                "Variant Barcode": row["barcode"],
                "Image Src": product_image if is_first else "",
                "Image Position": "1" if is_first and product_image else "",
                "Image Alt Text": parent_title if is_first else "",
                "Gift Card": "FALSE" if is_first else "",
                "SEO Title": parent_title if is_first else "",
                "SEO Description": (
                    f"{parent_title} from {first['brand']}." if first["brand"] else parent_title
                ) if is_first else "",
                "Google Shopping / Google Product Category": "",
                "Variant Image": row["image_url"],
                "Variant Weight Unit": "kg",
                "Status": product_status,
            })
    return out


def bigcommerce_rows(rows: list[dict]) -> list[dict]:
    out = []
    for row in rows:
        if row["status"] == "discontinued":
            continue
        out.append({
            "Product Name": row["product_name"],
            "Product Code/SKU": row["sku"],
            "Brand Name": row["brand"],
            "Category": row["category"],
            "Price": row["price_gbp"],
            "Retail Price": row["price_gbp"],
            "Sale Price": "",
            "Product Description": f"{row['product_name']} by {row['brand'] or 'brand to confirm'}.",
            "Product Image URL": row["image_url"],
            "Product URL": "",
            "Product Condition": "New",
            "Product Weight": "",
            "Product Width": "",
            "Product Height": "",
            "Product Depth": "",
            "Allow Purchases": "Y" if row["import_status"] == "Ready" else "N",
            "Product Visible": "Y" if row["import_status"] == "Ready" else "N",
            "Product Availability": "available" if row["import_status"] == "Ready" else "disabled",
            "Track Inventory": "Y",
            "Current Stock Level": "0",
            "Low Stock Level": "",
            "Product Barcode": row["barcode"],
            "Variant SKU": row["sku"],
            "Variant Price": row["price_gbp"],
            "Variant Image URL": row["image_url"],
            "Variant Inventory Level": "0",
            "Option Name": row["option_name"],
            "Option Value": row["option_value"],
        })
    return out


def generic_rows(rows: list[dict]) -> list[dict]:
    out = []
    for row in rows:
        out.append({
            "sku": row["sku"],
            "parent_sku": row["parent_sku"],
            "product_name": row["product_name"],
            "brand": row["brand"],
            "category": row["category"],
            "price_gbp": row["price_gbp"],
            "currency": "GBP",
            "image_url": row["image_url"],
            "barcode": row["barcode"],
            "status": row["status"],
            "option_name": row["option_name"],
            "option_value": row["option_value"],
            "import_status": row["import_status"],
            "review_flags": row["review_flags"],
            "source_file": row["source_file"],
            "source_row": row["source_row"],
        })
    return out


# ---------------------------------------------------------------------------
# Workbook
# ---------------------------------------------------------------------------

def style_header(ws, row: int, columns: int) -> None:
    for col in range(1, columns + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = Font(bold=True, color=OAT)
        cell.fill = PatternFill("solid", fgColor=CHERRY)
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 28


def write_sheet(ws, headers: list[str], rows: list[list], widths: list[int] | None = None) -> None:
    ws.append(headers)
    style_header(ws, 1, len(headers))
    for row in rows:
        ws.append(row)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{ws.max_row}"
    if widths:
        for i, width in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = width
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=False)


def build_workbook(rows: list[dict], review: list[dict], changes: list[dict], duplicates: list[dict], summary: dict) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Supplier catalogue cleanup"
    ws["A1"].font = Font(size=22, bold=True, color=CHERRY)
    ws["A2"] = "Three supplier files → 250 unique SKUs → import-ready outputs"
    ws["A2"].font = Font(size=12, color=MUTED)
    ws["A4"] = "This is a synthetic portfolio sample, not client work. Prices, images and barcodes are fictional."
    ws["A4"].font = Font(italic=True, color=MUTED)
    ws.merge_cells("A4:F4")

    metrics = [
        ("Unique SKUs", summary["unique_skus"]),
        ("Raw supplier rows", summary["raw_rows"]),
        ("Duplicate rows removed", summary["duplicate_rows_removed"]),
        ("Import-ready", summary["ready"]),
        ("Need a supplier answer", summary["review"]),
        ("Discontinued", summary["discontinued"]),
    ]
    row = 6
    for label, value in metrics:
        ws.cell(row=row, column=1, value=label).font = Font(bold=True, color=CHERRY)
        ws.cell(row=row, column=2, value=value).font = Font(size=14)
        row += 1

    row += 1
    ws.cell(row=row, column=1, value="Issue checks").font = Font(size=14, bold=True, color=CHERRY)
    row += 1
    issue_rows = [
        ("Duplicate SKU rows removed", summary["duplicate_rows_removed"]),
        ("Inconsistent SKU formats normalised", summary["sku_formats_normalised"]),
        ("Price formats found", summary["price_formats"]),
        ("Missing prices", summary["missing_prices"]),
        ("Missing image links", summary["missing_images"]),
        ("Broken image links", summary["broken_images"]),
        ("Duplicate title groups resolved", summary["duplicate_title_groups"]),
        ("Category mismatches corrected", summary["category_mismatches"]),
        ("Categories filled from product type", summary["categories_filled_from_type"]),
        ("Missing categories", summary["missing_categories"]),
        ("Invalid barcodes", summary["invalid_barcodes"]),
        ("Missing brands", summary["missing_brands"]),
        ("Discontinued items", summary["discontinued"]),
        ("Whitespace/case rows normalised", summary["whitespace_case_rows"]),
    ]
    ws.cell(row=row, column=1, value="Check").font = Font(bold=True)
    ws.cell(row=row, column=2, value="Count").font = Font(bold=True)
    row += 1
    for label, value in issue_rows:
        ws.cell(row=row, column=1, value=label)
        ws.cell(row=row, column=2, value=value)
        row += 1

    row += 1
    ws.cell(row=row, column=1, value="What this is").font = Font(size=12, bold=True, color=CHERRY)
    row += 1
    for line in [
        "A reproducible sample built from three fictional supplier files.",
        "A cleaned master, issue queue, change log and three import-format examples.",
        "A demonstration of rules: normalise, preserve, flag, and do not guess.",
    ]:
        ws.cell(row=row, column=1, value=line)
        row += 1
    row += 1
    ws.cell(row=row, column=1, value="What this is not").font = Font(size=12, bold=True, color=CHERRY)
    row += 1
    for line in [
        "Not a live store import. Test a small batch against the destination platform.",
        "Not proof of client work or commercial results.",
        "Not a substitute for supplier confirmation of missing prices, images, barcodes or categories.",
    ]:
        ws.cell(row=row, column=1, value=line)
        row += 1
    row += 1
    ws.cell(row=row, column=1, value="Reproducibility").font = Font(size=12, bold=True, color=CHERRY)
    ws.cell(row=row + 1, column=1, value="Seed 20261119. Run python build_supplier_catalogue.py. All records are synthetic.")
    ws.column_dimensions["A"].width = 48
    ws.column_dimensions["B"].width = 12
    ws.column_dimensions["C"].width = 3
    ws.column_dimensions["D"].width = 60

    # Cleaned catalogue.
    ws = wb.create_sheet("Cleaned Catalogue")
    headers = [
        "SKU", "Parent SKU", "Product name", "Brand", "Category", "Price (GBP)",
        "Price status", "Image URL", "Image status", "Barcode", "Barcode status",
        "Status", "Option name", "Option value", "Import status", "Review flags",
        "Source file", "Source row", "Source SKU", "Source price",
    ]
    data = [[
        r["sku"], r["parent_sku"], r["product_name"], r["brand"], r["category"],
        r["price_gbp"], r["price_status"], r["image_url"], r["image_status"],
        r["barcode"], r["barcode_status"], r["status"], r["option_name"],
        r["option_value"], r["import_status"], r["review_flags"],
        r["source_file"], r["source_row"], r["source_sku"], r["source_price"],
    ] for r in rows]
    write_sheet(ws, headers, data, [18, 18, 42, 20, 14, 12, 12, 46, 12, 18, 12, 12, 14, 14, 14, 40, 16, 10, 20, 14])
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        status = row[14].value
        if status == "Ready":
            row[14].fill = PatternFill("solid", fgColor=PALE_GREEN)
        elif status == "Review":
            row[14].fill = PatternFill("solid", fgColor="F7DDE1")
        else:
            row[14].fill = PatternFill("solid", fgColor="E6D4DF")

    # Review queue.
    ws = wb.create_sheet("Review Queue")
    headers = ["SKU", "Issue", "Blocking", "Source value", "Cleaned value", "Rule", "Next action", "Source file", "Source row"]
    data = [[
        r["sku"], r["issue"], "Yes" if r["blocking"] else "No",
        r["source_value"], r["cleaned_value"], r["rule"],
        r["next_action"], r["source_file"], r["source_row"],
    ] for r in review]
    write_sheet(ws, headers, data, [18, 30, 10, 30, 30, 55, 55, 16, 10])

    # Changes.
    ws = wb.create_sheet("Changes")
    headers = ["SKU", "Field", "Before", "After", "Rule", "Source file", "Source row"]
    data = [[
        r["sku"], r["field"], r["before"], r["after"], r["rule"],
        r["source_file"], r["source_row"],
    ] for r in changes]
    write_sheet(ws, headers, data, [18, 16, 36, 36, 65, 16, 10])

    # Duplicates.
    ws = wb.create_sheet("Duplicates")
    headers = ["SKU", "Source file", "Source rows", "Rows removed", "Rule"]
    data = [[
        d["sku"], d["source_file"], ", ".join(str(x) for x in d["source_rows"]),
        d["rows_removed"], d["rule"],
    ] for d in duplicates]
    write_sheet(ws, headers, data, [18, 16, 20, 14, 70])

    # Raw source sheets.
    for file_key, path, sheet_name in [
        ("A", RAW / "supplier-a.csv", "Source A"),
        ("B", RAW / "supplier-b.xlsx", "Source B"),
        ("C", RAW / "supplier-c.csv", "Source C"),
    ]:
        if file_key == "B":
            source_wb = load_workbook(path, data_only=True)
            source_ws = source_wb["Products"]
            ws = wb.create_sheet(sheet_name)
            for row in source_ws.iter_rows(values_only=True):
                ws.append(list(row))
            ws.freeze_panes = "A3"
            ws.auto_filter.ref = f"A2:L{ws.max_row}"
            for col in range(1, 13):
                ws.column_dimensions[get_column_letter(col)].width = 18
        else:
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.reader(handle)
                ws = wb.create_sheet(sheet_name)
                for row in reader:
                    ws.append(row)
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = f"A1:L{ws.max_row}"
            for col in range(1, 13):
                ws.column_dimensions[get_column_letter(col)].width = 18

    # Import-ready sheets.
    for name, headers, data in [
        ("Shopify Import", list(shopify_rows(rows)[0].keys()) if rows else [], [list(r.values()) for r in shopify_rows(rows)]),
        ("BigCommerce Import", list(bigcommerce_rows(rows)[0].keys()) if rows else [], [list(r.values()) for r in bigcommerce_rows(rows)]),
        ("Generic Import", list(generic_rows(rows)[0].keys()) if rows else [], [list(r.values()) for r in generic_rows(rows)]),
    ]:
        ws = wb.create_sheet(name)
        write_sheet(ws, headers, data)
        ws.auto_filter.ref = f"A1:{get_column_letter(max(1, len(headers)))}{ws.max_row}"

    path = BASE / "Supplier_Catalogue_Review.xlsx"
    wb.save(path)
    return path


# ---------------------------------------------------------------------------
# Site data
# ---------------------------------------------------------------------------

def build_site_data(
    rows: list[dict],
    summary: dict,
    changes: list[dict],
    review: list[dict],
    duplicates: list[dict],
    validation: dict,
) -> dict:
    records = []
    for row in rows:
        records.append({
            "sku": row["sku"],
            "parent_sku": row["parent_sku"],
            "product_name": row["product_name"],
            "brand": row["brand"],
            "category": row["category"],
            "price_gbp": row["price_gbp"],
            "image_status": row["image_status"],
            "barcode_status": row["barcode_status"],
            "status": row["status"],
            "option_name": row["option_name"],
            "option_value": row["option_value"],
            "import_status": row["import_status"],
            "review_flags": row["review_flags"],
            "source_file": row["source_file"],
            "source_row": row["source_row"],
        })

    # Pick one clear example for each field, preferring changes where both the
    # before and after values are visible.
    selected_changes = []
    for field in ("SKU", "Price", "Product name", "Brand", "Category"):
        candidates = [
            change for change in changes
            if change["field"] == field and change["before"] and change["after"]
        ]
        if field == "Category":
            corrected = [change for change in candidates if "conflicts" in change["rule"]]
            if corrected:
                candidates = corrected
        if candidates:
            selected_changes.append(candidates[0])

    merge_changes = [
        change for change in changes
        if "Duplicate SKU merge" in change["rule"]
    ]
    if merge_changes:
        selected_changes.append(merge_changes[0])

    # One source row that shows both an SKU and a price format change, so the
    # page does not mix two different examples in the same before/after panel.
    format_example = None
    sku_change = next((change for change in changes if change["field"] == "SKU"), None)
    if sku_change:
        source_row = next((row for row in rows if row["sku"] == sku_change["sku"]), None)
        if source_row:
            format_example = {
                "sku": source_row["sku"],
                "source_sku": source_row["source_sku"],
                "clean_sku": source_row["sku"],
                "source_price": source_row["source_price"],
                "clean_price": f"£{source_row['price_gbp']}" if source_row["price_gbp"] else "No firm price",
                "source_file": source_row["source_file"],
                "source_row": source_row["source_row"],
            }

    selected_review = []
    wanted_issues = [
        "Missing image link",
        "Broken image link",
        "Invalid barcode",
        "Missing or non-numeric price",
        "Missing brand",
        "Missing category",
    ]
    for issue in wanted_issues:
        candidates = [entry for entry in review if entry["issue"] == issue]
        if candidates:
            selected_review.append(candidates[0])

    selected_duplicates = sorted(
        duplicates,
        key=lambda entry: (not entry.get("merged_fields"), entry["sku"]),
    )[:3]
    field_labels = {
        "image_url": "Image URL",
        "barcode": "Barcode",
        "price": "Price",
        "product_name": "Product name",
        "brand": "Brand",
        "category": "Category",
        "product_type": "Product type",
        "parent_sku": "Parent SKU",
        "option_name": "Option name",
        "option_value": "Option value",
        "status": "Status",
    }
    for entry in selected_duplicates:
        entry["merged_field_labels"] = [
            field_labels.get(field, field) for field in entry.get("merged_fields", [])
        ]

    return {
        "generated": "2026-11-19",
        "seed": SEED,
        "summary": summary,
        "validation": validation,
        "examples": {
            "format": format_example,
            "changes": selected_changes[:8],
            "review": selected_review[:8],
            "duplicates": selected_duplicates,
        },
        "records": records,
    }


def main() -> None:
    products = build_master()
    assign_defects(products)
    build_raw_rows(products)
    rows, meta = clean_catalogue(products)
    summary = meta["summary"]

    # Write cleaned CSVs.
    write_csv(
        CLEAN / "supplier-catalogue-standardised.csv",
        rows,
        ["sku", "parent_sku", "product_name", "brand", "category", "category_status",
         "price_gbp", "price_status", "image_url", "image_status", "barcode",
         "barcode_status", "status", "option_name", "option_value", "import_status",
         "review_flags", "source_file", "source_row", "source_sku", "source_price"],
    )
    write_csv(
        CLEAN / "supplier-catalogue-review.csv",
        meta["review"],
        ["sku", "issue", "blocking", "source_value", "cleaned_value", "rule", "next_action", "source_file", "source_row"],
    )
    write_csv(
        CLEAN / "supplier-catalogue-changes.csv",
        meta["changes"],
        ["sku", "field", "before", "after", "rule", "source_file", "source_row"],
    )

    # Import-ready files.
    shop = shopify_rows(rows)
    big = bigcommerce_rows(rows)
    generic = generic_rows(rows)
    write_csv(IMPORT / "shopify-import.csv", shop, list(shop[0].keys()))
    write_csv(IMPORT / "bigcommerce-import.csv", big, list(big[0].keys()))
    write_csv(IMPORT / "generic-import.csv", generic, list(generic[0].keys()))

    shop_handles = [row["Handle"] for row in shop]
    shop_skus = [row["Variant SKU"] for row in shop]
    titled_handles = [row["Handle"] for row in shop if row["Title"]]
    if len(shop_skus) != len(set(shop_skus)):
        raise AssertionError("Shopify import contains a duplicate SKU.")
    if len(titled_handles) != len(set(titled_handles)):
        raise AssertionError("Shopify import contains more than one title row per handle.")

    validation = meta["validation"]
    validation.update({
        "shopify_rows": len(shop),
        "shopify_handles": len(set(shop_handles)),
        "shopify_variant_rows": sum(1 for row in shop if not row["Title"]),
        "shopify_unique_skus": len(set(shop_skus)),
        "shopify_active_products": sum(1 for row in shop if row["Title"] and row["Published"] == "TRUE"),
        "shopify_draft_products": sum(1 for row in shop if row["Title"] and row["Published"] != "TRUE"),
        "bigcommerce_rows": len(big),
        "bigcommerce_visible_rows": sum(1 for row in big if row["Product Visible"] == "Y"),
        "bigcommerce_hidden_rows": sum(1 for row in big if row["Product Visible"] != "Y"),
        "generic_rows": len(generic),
    })

    # Workbook.
    workbook_path = build_workbook(rows, meta["review"], meta["changes"], meta["duplicates"], summary)

    site_data = build_site_data(
        rows, summary, meta["changes"], meta["review"], meta["duplicates"], validation
    )
    (SITE / "supplier-catalogue-data.json").write_text(json.dumps(site_data, indent=2), encoding="utf-8")

    # Summary files for the page and evidence package.
    (DOCS / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (DOCS / "duplicate-log.json").write_text(json.dumps(meta["duplicates"], indent=2), encoding="utf-8")
    (DOCS / "validation.json").write_text(json.dumps(validation, indent=2), encoding="utf-8")

    print(json.dumps(summary, indent=2))
    print(json.dumps(validation, indent=2))
    print(f"Workbook: {workbook_path}")
    print(f"Raw rows: {meta['raw_counts']}")
    print(f"Review rows: {len(meta['review'])}")
    print(f"Change rows: {len(meta['changes'])}")


if __name__ == "__main__":
    main()
