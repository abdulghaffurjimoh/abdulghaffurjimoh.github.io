# Supplier Catalogue Cleanup — Evidence Package

**Project:** Three supplier files to one import-ready catalogue
**Snapshot:** 19 November 2026
**Seed:** 20261119
**Status:** Synthetic portfolio sample, not client work

This package documents a reproducible supplier-catalogue cleanup. Three fictional supplier files in three different layouts were standardised into one cleaned master, a review queue, a change log and three platform export shapes.

No real supplier, customer, product, price, image or barcode data is included. All company names, product names, prices, image URLs and barcodes are fictional. The sample exists to show the rules and the handover, not commercial results.

---

## Result at a glance

| Measure | Result |
|---|---:|
| Raw supplier rows | 268 |
| Unique SKUs in cleaned master | 250 |
| Duplicate rows merged | 18 |
| Inconsistent SKU formats normalised | 12 |
| Price styles found | 9 |
| Missing prices (including POA) | 5 |
| Missing image links | 14 |
| Broken image links | 7 |
| Duplicate-title groups resolved | 6 (16 rows) |
| Category mismatches corrected | 5 |
| Missing categories | 4 |
| Invalid barcodes blanked and queued | 4 |
| Missing brands | 3 |
| Discontinued items | 3 |
| Rows with a whitespace or case fix | 55 |
| Import-ready SKUs | 210 |
| SKUs held for a supplier answer | 37 |
| Change-log entries | 336 |
| Review-queue entries | 53 (37 blocking, 16 non-blocking title checks) |

The 37 blocked SKUs break down as **21 image problems** (14 missing + 7 broken), **5 missing prices**, **4 invalid barcodes**, **4 missing categories** and **3 missing brands**. In this sample each blocked SKU has exactly one blocking issue, so those groups add up to 37. The 3 discontinued items are counted separately and excluded from the platform files.

### What the status labels mean

- **Ready** — the row has a brand, category, two-decimal price, image URL and valid barcode, and passes the checks used here. It is not a live store import or supplier approval.
- **Review** — at least one blocking field is missing or invalid. The cleaned row remains in the master; the platform row is draft or hidden.
- **Discontinued** — excluded from the Shopify and BigCommerce files, retained in the generic master for audit.

---

## Source files

| File | Layout | Raw rows | Unique SKUs |
|---|---|---:|---:|
| `raw/supplier-a.csv` | One header row, 12 columns, mixed SKU punctuation and price styles | 106 | 100 |
| `raw/supplier-b.xlsx` | Two header rows, merged group headings, 12 columns | 96 | 90 |
| `raw/supplier-c.csv` | Lower-case headers with different column names | 66 | 60 |
| **Total** | | **268** | **250** |

Each supplier file contains six repeated rows and a share of the seeded field defects. The cleaned master keeps the source file and source row for every record.

---

## File map

| Path | What it contains |
|---|---|
| `build_supplier_catalogue.py` | Generator, cleaner, validator, workbook builder and evidence exporter |
| `Supplier_Catalogue_Review.xlsx` | 11-sheet workbook: Summary, Cleaned Catalogue, Review Queue, Changes, Duplicates, Source A, Source B, Source C, Shopify Import, BigCommerce Import, Generic Import |
| `clean/supplier-catalogue-standardised.csv` | Full 250-SKU cleaned master with status, review flags and source references |
| `clean/supplier-catalogue-review.csv` | 53 review-queue entries with rule, next action and blocking flag |
| `clean/supplier-catalogue-changes.csv` | 336 field-level changes with before, after, rule and source row |
| `import-ready/shopify-import.csv` | 247 rows, 217 handles, 30 later variant rows; 186 active products, 31 draft products |
| `import-ready/bigcommerce-import.csv` | 247 rows, one per SKU; 210 visible, 37 hidden |
| `import-ready/generic-import.csv` | 250 rows including discontinued items, with import status and review flags |
| `raw/` | The three original supplier files, unchanged |
| `docs/summary.json` | Machine-readable issue counts |
| `docs/validation.json` | Automated validation results |
| `docs/duplicate-log.json` | Duplicate groups with both source rows and merged fields |
| `site/supplier-catalogue-data.json` | Record browser data and curated examples used by the case-study page |
| `manifest.json` | SHA-256 hash, byte size and path for every file in this package |
| `README.md` | This document |

The case-study page and its CSS/JavaScript are published with the portfolio site at https://abdulghaffurjimoh.github.io/supplier-catalogue-case-study.html. This package focuses on the data and the evidence.

---

## Rules applied

### SKU

- Trim leading and trailing spaces.
- Uppercase letters.
- Replace spaces, underscores, dots and slashes with hyphens.
- Collapse repeated hyphens.
- Do not change the underlying letters or numbers.

Example: `FN.KIT.0004` → `FN-KIT-0004`.

### Price

- Parse `£`, `GBP` prefix, `GBP` suffix, comma decimals and whole-pound formats.
- Standardise to two decimal places.
- Preserve the exact value. One-decimal and whole-pound source styles are used only where the price is already exact at that precision, so no pence are invented or discarded.
- Do not guess `POA` or blank prices. The cleaned price stays blank and the SKU enters the review queue.

Example: `32,41` → `32.41` (displayed as `£32.41` on the page).

### Product titles

- Trim and collapse whitespace.
- Restore title case for supplier-style names.
- When a title repeats because a variant option is missing, append the option value (or the brand) and record the change.
- Do not rewrite product identity, pack size or descriptions.

### Duplicates

- Group rows by normalised SKU.
- Keep the row with the most non-empty fields, then the earliest source row.
- Fill blanks only from another row with the same normalised SKU.
- Record both source rows, the removed-row count and any filled fields.
- Do not merge different SKUs or infer that similarly named products are the same item.

### Barcodes

- Validate GTIN length and check digit.
- Keep valid barcodes as text.
- Leave invalid barcodes blank in the cleaned output, add a review entry and ask the supplier to confirm the correct EAN/GTIN.
- Do not repair a barcode by guessing a digit.

### Categories and brands

- Restore the canonical spelling and whitespace.
- Where the supplier department conflicts with the product type, use the product type and log the correction.
- Do not invent a category or brand when the source is blank.

### Images

- Check for a missing URL and for the sampled broken-URL patterns.
- Keep usable URLs unchanged.
- Leave missing or broken URLs blank and queue a replacement request.
- The sample does not make live HTTP requests; "broken" describes the synthetic fixture.

### Variants

- Preserve parent SKU, option name and option value.
- In the Shopify file, group variant rows under one handle. Product-level fields appear on the first row only; later rows carry variant data.
- In the BigCommerce and generic files, keep one row per SKU.

---

## Validation

The generator compares every cleaned row with the synthetic master and fails if a rule is broken. The current run reports:

- 250 master SKUs and 250 output SKUs.
- 250 unique titles and 0 duplicate titles after cleaning.
- 246 valid barcodes; 4 invalid barcodes blanked; no duplicate non-empty barcodes.
- 210 Ready, 37 Review, 3 Discontinued.
- 0 validation failures.
- Shopify: 247 rows, 217 handles, 30 later variant rows, 247 unique SKUs, 186 active products, 31 draft products.
- BigCommerce: 247 rows, 210 visible, 37 hidden.
- Generic: 250 rows.

The full result is in `docs/validation.json`.

---

## Reproduce it

Requirements: Python 3, `openpyxl`.

```powershell
cd supplier-catalogue-case-study
python build_supplier_catalogue.py
```

The script rewrites every raw file, cleaned CSV, import file, workbook, JSON document and the page record data. It prints the summary and validation result. The seed is fixed at `20261119`, so the same inputs and counts should be produced again.

The raw supplier files are generated by the same script. To inspect the inputs, open `raw/` before rerunning; the script overwrites them with the same seeded content.

---

## Limitations

- **Synthetic data.** No real supplier or customer data is used. Counts describe this sample only.
- **No live import.** The files have not been tested against a live Shopify, BigCommerce or other store. Platform schemas change; test a small batch before scaling up.
- **No supplier approval.** "Ready" means the row passes the checks shown here. It does not mean a supplier has confirmed the price, image, barcode or category.
- **No commercial result.** This is not client work and does not claim saved time, increased sales or reduced errors in a real business.
- **Barcode validation is structural.** A valid check digit does not prove that a barcode is registered to the right product.
- **Image checks are sampled.** A URL that looks valid may still fail in a browser or storefront.
- **One blocking issue per reviewed SKU in this sample.** Real supplier files often combine several problems in one row; the review queue is designed to hold more than one entry per SKU even though this sample does not need that.
- **Not a data dictionary for every platform.** The import files use common fields and should be mapped against the destination's current schema.

---

## Disclosure

This package is a portfolio sample. If it is shared with a prospect, keep the synthetic label visible and do not present the counts as client results. The case-study page states the same limitation.

Portfolio: https://abdulghaffurjimoh.github.io/
Case study: https://abdulghaffurjimoh.github.io/supplier-catalogue-case-study.html
